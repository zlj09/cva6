require_extension('D');
require_rv64;
require_fp;
WRITE_RD(FRS1.v[0]);
