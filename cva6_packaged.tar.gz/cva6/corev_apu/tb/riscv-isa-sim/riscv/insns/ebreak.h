throw trap_breakpoint(pc);
