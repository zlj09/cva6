require_extension('C');
throw trap_breakpoint(pc);
