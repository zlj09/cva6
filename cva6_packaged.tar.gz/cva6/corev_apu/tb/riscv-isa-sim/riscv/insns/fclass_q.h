require_extension('Q');
require_fp;
WRITE_RD(f128_classify(f128(FRS1)));
