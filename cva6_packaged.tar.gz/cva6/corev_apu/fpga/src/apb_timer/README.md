# APB Timer

This unit provides a simple timer via the APB bus.
It supports an arbitrary number of 32-bit wide timers. Each timer has three
registers, the timer register, the timer compare register and the timer control
register.
