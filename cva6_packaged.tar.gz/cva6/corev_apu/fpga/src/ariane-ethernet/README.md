This is a port of the Alex Forencich GHz RGMII Ethernet MAC to the Digilent Genesys2 board.
It is intended for use with https://github.com/pulp-platform/ariane (a RISCV Linux-capable soft core).
